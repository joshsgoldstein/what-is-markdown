Nine reusable standalone illustrations for Lost In AI Land.

Notebook: docker-notebook.png plus notebook-cli.png, notebook-git.png, notebook-markdown.png. The three smaller notebook illustrations have transparent backgrounds.
Magazine: docker-magazine.png plus cli.png, git.png, markdown.png.
Stories: docker-stories.png plus the same illustrated covers.

Each matching JSON in prompts/ records the exact generation prompt, reference image, and transparency setting. Reference mockups remain in the full archive and repository. These assets can be reused directly. Original PNGs are preserved without recompression.
