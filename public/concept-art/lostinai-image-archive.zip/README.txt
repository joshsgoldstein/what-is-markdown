Lost In AI Land image archive

Original PNG files are preserved byte for byte. Duplicate copies are included once.
public/concept-art: three generated concept mockups and six live design screenshots.
public/images: article artwork, diagrams, PNG exports of the CLI/Git SVG covers, and social image.
design: earlier publication screenshots.
image-prompts: saved dinosaur prompts.

Artwork inside a generated full-page mockup remains part of that original PNG; separate source layers were not generated.
manifest.json records dimensions and SHA-256 hashes.
